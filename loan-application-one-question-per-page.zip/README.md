# Multi-page Loan Application Form

A mobile-friendly, one-question-per-screen form template.

## Files
- `index.html` — form screens and content
- `styles.css` — design and responsive layout
- `app.js` — page navigation, validation and review
- `README.md` — these instructions

## Pages
1. Full names
2. Mobile phone number
3. Repayment period
4. Requested loan amount
5. Review and confirmation
6. Demo completion message

## Important: demo only
This is a front-end demonstration. It does not send, save, or process applications. Do not publish it as a live application intake form until a secure backend, appropriate privacy notice, access controls, data retention rules, and applicable legal/regulatory checks are in place.

Never ask customers for a PIN, password, OTP, or account security code. Use only a business name, logo, and provider-affiliation statement you are legally authorized to use. This template is not an official HaloPesa website or endorsement.

## Change the business name
Open `app.js` and change:
`const BUSINESS_NAME = "Your Lending Business";`

## Change the colours
Open `styles.css` and edit the colour variables at the top under `:root`.

## Deploy on Vercel through GitHub
1. Upload all four files to the top level of a GitHub repository.
2. In Vercel, import that GitHub repository.
3. Select **Other** as the framework preset.
4. Leave the build command empty. If Vercel asks for an output directory, use `.`.
5. Deploy.

When the GitHub repository is connected to Vercel, future commits can trigger automatic deployments.
