// Change this to your own approved business name.
const BUSINESS_NAME = "Your Lending Business";

document.getElementById("businessName").textContent = BUSINESS_NAME;
document.title = `${BUSINESS_NAME} | Loan Application`;

const form = document.getElementById("applicationForm");
const pages = [...document.querySelectorAll(".page")];
const dots = [...document.querySelectorAll(".step-dot")];
const progressBar = document.getElementById("progressBar");
const stepText = document.getElementById("stepText");
const percentText = document.getElementById("percentText");
let currentPage = 1;
const lastFormPage = 5;

function showPage(pageNumber) {
  currentPage = pageNumber;
  pages.forEach(page => page.classList.toggle("active", Number(page.dataset.page) === pageNumber));
  const completed = pageNumber === 6 ? 100 : Math.round((pageNumber / lastFormPage) * 100);
  progressBar.style.width = `${completed}%`;
  stepText.textContent = pageNumber === 6 ? "Completed" : `Step ${pageNumber} of ${lastFormPage}`;
  percentText.textContent = `${completed}% ${pageNumber === 6 ? "complete" : "complete"}`;
  dots.forEach((dot, index) => {
    dot.classList.toggle("current", index + 1 === pageNumber);
    dot.classList.toggle("done", index + 1 < pageNumber || pageNumber === 6);
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function validateCurrentPage() {
  const page = document.querySelector(`.page[data-page="${currentPage}"]`);
  const field = page.querySelector("input[required], select[required]");
  if (field && !field.checkValidity()) {
    field.reportValidity();
    field.focus();
    return false;
  }
  if (currentPage === 1) {
    const name = document.getElementById("fullName").value.trim();
    if (name.split(/\s+/).length < 2) {
      const input = document.getElementById("fullName");
      input.setCustomValidity("Please enter your first and last name.");
      input.reportValidity();
      input.focus();
      input.setCustomValidity("");
      return false;
    }
  }
  if (currentPage === 2) {
    const phone = document.getElementById("phone");
    const digits = phone.value.replace(/\D/g, "");
    if (digits.length < 9 || digits.length > 13) {
      phone.setCustomValidity("Enter a valid phone number.");
      phone.reportValidity();
      phone.focus();
      phone.setCustomValidity("");
      return false;
    }
  }
  return true;
}

function safeText(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}

function buildReview() {
  const rows = [
    ["Full names", document.getElementById("fullName").value.trim()],
    ["Phone number", document.getElementById("phone").value.trim()],
    ["Repayment period", document.getElementById("period").value],
    ["Requested amount", `KES ${Number(document.getElementById("amount").value).toLocaleString("en-KE")}`]
  ];
  document.getElementById("review").innerHTML = rows.map(([label, value]) =>
    `<div><dt>${safeText(label)}</dt><dd>${safeText(value)}</dd></div>`
  ).join("");
}

document.querySelectorAll(".next").forEach(button => {
  button.addEventListener("click", () => {
    if (!validateCurrentPage()) return;
    if (currentPage === 4) buildReview();
    showPage(Math.min(lastFormPage, currentPage + 1));
  });
});

document.querySelectorAll(".back").forEach(button => {
  button.addEventListener("click", () => showPage(Math.max(1, currentPage - 1)));
});

form.addEventListener("submit", event => {
  event.preventDefault();
  if (!document.getElementById("consent").checked) {
    alert("Please tick the confirmation box before continuing.");
    document.getElementById("consent").focus();
    return;
  }
  // Demonstration only: no application details are transmitted or stored.
  showPage(6);
});

document.getElementById("restart").addEventListener("click", () => {
  form.reset();
  showPage(1);
});
